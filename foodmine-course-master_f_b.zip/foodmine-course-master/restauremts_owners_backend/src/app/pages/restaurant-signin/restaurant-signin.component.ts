import { Component } from '@angular/core';

@Component({
  selector: 'app-restaurant-signin',
  templateUrl: './restaurant-signin.component.html',
  styleUrls: ['./restaurant-signin.component.css']
})
export class RestaurantSigninComponent {

}
